#include <stdio.h>
#include <string.h>

#define MAX_NISKA 101

int main()
{
    char s[MAX_NISKA];
    char niska[MAX_NISKA];
    int n;
    
    scanf("%s",s);
    scanf("%d",&n);
    if(n <= 0 || n > 100)
    {
        printf("-1");
        return -1;
    }

    int i;
    int prefiks, sufiks;
    
    int l1 = strlen(s);
    
    for(i = 0; i < n; i++)
    {
        prefiks = 1;
        sufiks = 1;
        
        scanf("%s",niska);
        
        int j;
        
        int l2 = strlen(niska);
        
        if(l1 > l2)
            continue;
            
        for(j = 0; j < l1; j++)
        {
            if(niska[j] != s[j])
            {
                prefiks = 0;
                break;
            }
        }
        
        for(j = 0; j < l1; j++)
        {
            if(niska[l2 - l1 + j] != s[j])
            {
                sufiks = 0;
                break;
            }
        }
        
        if(prefiks || sufiks)
            printf("%s\n", niska);
        
    }
    

    return 0;
}
