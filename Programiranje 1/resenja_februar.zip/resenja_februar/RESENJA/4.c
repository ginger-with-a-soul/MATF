#include <stdio.h>
#include <string.h>

#define MAX_KLUB 21
#define MAX_DUEL 1000
#define MAX_STADION 30

typedef struct {
    char domacin[MAX_KLUB];
    char gost[MAX_KLUB];
    char stadion[MAX_STADION];
    int gol_domacin;
    int gol_gost;
} DUEL;

int main()
{
    int n;
    DUEL niz[MAX_DUEL];
    
    scanf("%d", &n);
    getchar();
    
    if(n <= 0 || n > 1000)
    {
        printf("-1");
        return -1;
    }
    
    int i;
    for(i = 0; i < n; i++)
    {
        gets(niz[i].domacin);
        gets(niz[i].gost);
        gets(niz[i].stadion);
        
        scanf("%d", &niz[i].gol_domacin);
        scanf("%d", &niz[i].gol_gost);
        getchar();
        
        if(niz[i].gol_domacin < 0 || niz[i].gol_gost < 0)
            {
                printf("-1");
                return -1;
            }
    }
    
    int indeks_max = 0;
    
    for(i = 1; i < n; i++)
    {
        if(abs(niz[i].gol_domacin - niz[i].gol_gost) > abs(niz[indeks_max].gol_domacin - niz[indeks_max].gol_gost))
            indeks_max = i;
    }
    
    printf("%s\n", niz[indeks_max].stadion);
    
    return 0;
}
