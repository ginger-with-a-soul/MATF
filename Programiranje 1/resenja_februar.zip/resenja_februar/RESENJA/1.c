#include <stdio.h>

int main()
{
    int n;
    int c;
    int broj;
    
    do
    {
        c = 0;
        scanf("%d", &n);
        broj = n;
        if(n != 0)
        {
            while(n != 0)
            {
              n = n / 10;
              c++;
            }
            
            if(c % 2 != 0)
                printf("%d ",broj);
        }
    } while(broj != 0);

    return 0;
}