#include <stdio.h>
#include <string.h>

#define MAX 100

int main()
{
    int matrica[MAX][MAX];
    
    int i, j;
    int n;
    
    int l, k;
    int suma = 0;
    
    scanf("%d", &n);
    
    if(n <= 0 || n > 50)
    {
        printf("-1");
        return -1;
    }
     
    scanf("%d", &k);
    scanf("%d", &l);
	 
    if(l < 0 || l >= n || k < 0 || k >= n || k>l)
    {
        printf("-1");
        return -1;
    }
    
    for(i = 0; i < n; i++)
        for(j = 0; j < n; j++)
            scanf("%d", &matrica[i][j]);
            
    
    for(i = k; i <= l; i++)
        for(j = k; j <= l; j++)
        {
            if(j == l || j == k || i == l || i == k)   
                suma += matrica[i][j];
        }

    printf("%d\n", suma);

    return 0;
}
