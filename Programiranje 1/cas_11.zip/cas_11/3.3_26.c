/* Napisati program koji sifrira unetu nisku tako sto svako
slovo zamenjuje sledecim slovom abecede, slova ’z’ i ’Z’ zamenjuje redom sa ’a’ i
’A’, a ostale karaktere ostavlja nepromenjene. Pretpostaviti da uneta niska nije
duža od 20 karaktera
*/

#include <stdio.h>
#include <ctype.h>

#define MAXLEN 20

void sifriraj(char s[]) {
    
    int i;
    
    /* prolazimo kroz nisku s sve dok ne naidjemo na terminirajucu nulu */
    for(i = 0; s[i]; i++)
        /* ukoliko je karakter slovo, primenjujemo sifriranje */    
        if(isupper(s[i]))
            s[i] = s[i] != 'Z' ? s[i] + 1 : 'A';
		else if(islower(s[i]))
			s[i] = s[i] != 'z' ? s[i] + 1 : 'a';         
}

int main() {

    /* u s se cuva uneta niska */
    char s[MAXLEN + 1];
    
    printf("Unesite nisku s: ");
    scanf("%s", s);
    
    sifriraj(s);
    printf("%s", s);
    
    return 0;
}
