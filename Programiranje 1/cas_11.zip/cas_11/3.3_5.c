#include <stdio.h>
#include <string.h>

#define MAXLEN 20

int sadrzi(char s[], char c) {
    
    int i;
    
    /* prolazimo kroz nisku s sve dok ne naidjemo na terminirajucu nulu */
    for(i = 0; s[i]; i++)
        /* ako smo naisli na karakter c, vracamo njegov indeks */
        if(s[i] == c)
            return i;
        
    /* ako se funkcija nije do sad zavrsila, 
     * znaci da se karakter ne nalazi u niski
     * pa treba vratiti -1 (nevalidan indeks za nisku)
     */
    return -1;
}

int main() {

    /* u s se cuva uneta niska */
    char s[MAXLEN + 1];
    /* u c se cuva uneti karakter */
    char c;
    int ind;
    
    printf("Unesite nisku s: ");
    scanf("%s", s);
    
    /* pokupimo belinu unetu nakon niske */
    getchar();
    
    printf("Unesite karakter c: ");
    c = getchar();
    
    ind = sadrzi(s, c);
    if(ind != -1)
        printf("Karakter \'%c\' se nalazi u niski \"%s\" (na poziciji %d)\n", c, s, ind);
    else
        printf("Karakter \'%c\' se ne nalazi u niski \"%s\"\n", c, s);
    
    return 0;
}
