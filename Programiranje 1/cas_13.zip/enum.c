#include <stdio.h>

/*
	Svaki element enumeracionog tipa ima celobrojnu vrednost
	Vrednosti pocinju od 0; svaki sledeci element tipa ima vrednost za 1
	vecu od elementa levo od sebe. Moguce je i eksplicitno naglasiti vrednost
	nekog elementa. U tom slucaju se vrednosti levo ne menjaju a pravilo da je 
	vrednost elementa za 1 veca od vrednosti elementa levo od sebe i dalje vazi.
*/
enum Boja {ZELENA, ZUTA=3, CRVENA} ;

/*
	tip ove enumeracije je enum Boja
*/
void semafor(enum Boja boja)
{
	/*
		Elementi enumeracije su konstante pa se mogu koristiti u switch-case naredbi.
	*/
	switch(boja)
	{
		case ZELENA: printf("Bezbedno je da prodjete!\n"); break;
		case ZUTA: printf("Usporite!\n"); break;
		case CRVENA: printf("Stanite!\n"); break;
	}
}

int main()
{
	printf("ZELENA: %d\n", ZELENA);
	printf("ZUTA: %d\n", ZUTA);
	printf("CRVENA: %d\n", CRVENA);
	semafor(ZUTA);
	return 0;
}