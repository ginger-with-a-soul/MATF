#include <stdio.h>

typedef struct Complex {

  float re;
  float im;
} Complex;  

Complex saberi(Complex *a, Complex *b) {

  Complex c;
  c.re = a->re + b->re;
  c.im = a->im + b->im;
  return c;
}

Complex oduzmi(Complex *a, Complex *b) {

  Complex c;
  c.re = a->re - b->re;
  c.im = a->im - b->im;
  return c;
}

int main() {

  Complex a, b;
  Complex c;
  
  printf("Unesite realni i imaginarni deo prvog broja: ");
  scanf("%f%f", &a.re, &a.im);

  printf("Unesite realni i imaginarni deo drugog broja: ");
  scanf("%f%f", &b.re, &b.im);
  
  c = saberi(&a, &b);
   /* Ukoliko je imaginarni deo negativan, 
	  * njegov zapis vec ukljucuje znak,
	  * te to treba proveriti.
	  * Inace, broj je oblika a+b*i.
    */
  printf("Zbir: %.2f%c%.2f*i\n", c.re, c.im > 0 ? '+' : ' ', c.im);
  
  c = oduzmi(&a, &b);
  printf("Razlika: %.2f%c%.2f*i\n", c.re, c.im > 0 ? '+' : ' ', c.im);
  
  c = pomnozi(&a, &b);
  printf("Proizvod: %.2f%c%.2f*i\n", c.re, c.im > 0 ? '+' : ' ', c.im);
  
  if(b.re != 0 || b.im != 0) {
    c = podeli(&a, &b);
    printf("Kolicnik: %.2f%c%.2f*i\n", c.re, c.im > 0 ? '+' : ' ', c.im);
  }
  /* U polju kompleksnih brojeva
   * nije dozvoljeno deljenje nulom.
   */
  else
    printf("Kolicnik ne postoji.\n"); 
					

  return 0;
}
