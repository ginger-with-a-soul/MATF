#include<stdio.h>

int min(int x, int y, int z){
	
	int m = x;
	if(m>y)
		m = y;
	if(m>z)
		m = z;

	return m;

}

int main(){

	int x, y, z;
	scanf("%d %d %d", &x, &y, &z);
	
	printf("Minumum je: %d\n", min(x, y, z));

	return 0;

}
