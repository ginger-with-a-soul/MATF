#include<stdio.h>
#include<stdlib.h>

int faktorijel(int x){

	int f = 1, i = 2;
	if(x==0 || x==1)
		return 1;

	while(i<=x){
		f *= i;
		i++;	
	}

	return f;
	
}

int main(){
	int x, y;
	scanf("%d %d", &x, &y);
		
	if(x<0 || x>12 || y<0 || y>12){
		printf("Greska\n");
		// funkcija exit prekida program 
		// definisana je u stdlib.h
		exit(EXIT_FAILURE);	
	}

	printf("%d! + %d! = %d\n", x, y, faktorijel(x)+faktorijel(y));
	return 0;	
}
